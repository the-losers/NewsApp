package com.lernr.teacher.ui.rate.interactor

import javax.inject.Inject

/**
 * Created by jyotidubey on 15/01/18.
 */
class RateUsInteractor @Inject internal constructor(apiHelper: com.lernr.teacher.data.network.ApiHelper, preferenceHelper: com.lernr.teacher.data.preferences.PreferenceHelper) : com.lernr.teacher.ui.base.interactor.BaseInteractor(apiHelper = apiHelper, preferenceHelper = preferenceHelper), com.lernr.teacher.ui.rate.interactor.RateUsMVPInterator {

    override fun submitRating() {}
}