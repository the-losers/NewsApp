package com.lernr.teacher.ui.feed.opensource.interactor

import io.reactivex.Observable
import javax.inject.Inject

/**
 * Created by jyotidubey on 14/01/18.
 */
class OpenSourceInteractor @Inject internal constructor(preferenceHelper: com.lernr.teacher.data.preferences.PreferenceHelper, apiHelper: com.lernr.teacher.data.network.ApiHelper) : com.lernr.teacher.ui.base.interactor.BaseInteractor(preferenceHelper, apiHelper), com.lernr.teacher.ui.feed.opensource.interactor.OpenSourceMVPInteractor {

    override fun getOpenSourceList(): Observable<com.lernr.teacher.data.network.OpenSourceResponse> {
        return apiHelper.getOpenSourceApiCall()
    }

}