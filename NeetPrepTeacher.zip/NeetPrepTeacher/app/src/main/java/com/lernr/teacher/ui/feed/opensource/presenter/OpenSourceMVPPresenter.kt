package com.lernr.teacher.ui.feed.opensource.presenter

/**
 * Created by jyotidubey on 14/01/18.
 */
interface OpenSourceMVPPresenter<V : com.lernr.teacher.ui.feed.opensource.view.OpenSourceMVPView, I : com.lernr.teacher.ui.feed.opensource.interactor.OpenSourceMVPInteractor> : com.lernr.teacher.ui.base.presenter.MVPPresenter<V, I> {

    fun onViewPrepared()
}