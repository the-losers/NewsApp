package com.lernr.teacher.data.preferences

import android.content.Context
import android.content.SharedPreferences
import androidx.content.edit
import javax.inject.Inject

/**
 * Created by jyotidubey on 04/01/18.
 */
class AppPreferenceHelper @Inject constructor(context: Context,
                                              @com.lernr.teacher.di.PreferenceInfo private val prefFileName: String) : com.lernr.teacher.data.preferences.PreferenceHelper {
    companion object {
        private val PREF_KEY_USER_LOGGED_IN_MODE = "PREF_KEY_USER_LOGGED_IN_MODE"
        private val PREF_KEY_CURRENT_USER_ID = "PREF_KEY_CURRENT_USER_ID"
        private val PREF_KEY_ACCESS_TOKEN = "PREF_KEY_ACCESS_TOKEN"
        private val PREF_KEY_CURRENT_USER_NAME = "PREF_KEY_CURRENT_USER_NAME"
        private val PREF_KEY_CURRENT_USER_EMAIL = "PREF_KEY_CURRENT_USER_EMAIL"
    }

    private val mPrefs: SharedPreferences = context.getSharedPreferences(prefFileName, Context.MODE_PRIVATE)

    override fun getCurrentUserLoggedInMode() = mPrefs.getInt(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_USER_LOGGED_IN_MODE, com.lernr.teacher.util.AppConstants.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT.type)

    override fun getCurrentUserName(): String = mPrefs.getString(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_CURRENT_USER_NAME, "ABC")

    override fun setCurrentUserName(userName: String?) = mPrefs.edit { putString(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_CURRENT_USER_NAME, userName) }

    override fun getCurrentUserEmail(): String = mPrefs.getString(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_CURRENT_USER_EMAIL, "abc@gmail.com")

    override fun setCurrentUserEmail(email: String?) = mPrefs.edit { putString(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_CURRENT_USER_EMAIL, email) }

    override fun getAccessToken(): String = mPrefs.getString(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_ACCESS_TOKEN, "")

    override fun setAccessToken(accessToken: String?) = mPrefs.edit { putString(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_ACCESS_TOKEN, accessToken) }

    override fun getCurrentUserId(): Long? {
        val userId = mPrefs.getLong(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_CURRENT_USER_ID, com.lernr.teacher.util.AppConstants.NULL_INDEX)
        return when (userId) {
            com.lernr.teacher.util.AppConstants.NULL_INDEX -> null
            else -> userId
        }
    }

    override fun setCurrentUserId(userId: Long?) {
        val id = userId ?: com.lernr.teacher.util.AppConstants.NULL_INDEX
        mPrefs.edit { putLong(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_CURRENT_USER_ID, id) }
    }

    override fun setCurrentUserLoggedInMode(mode: com.lernr.teacher.util.AppConstants.LoggedInMode) {
        mPrefs.edit { putInt(com.lernr.teacher.data.preferences.AppPreferenceHelper.Companion.PREF_KEY_USER_LOGGED_IN_MODE, mode.type) }
    }


}