package com.lernr.teacher.ui.base.presenter

import io.reactivex.disposables.CompositeDisposable


abstract class BasePresenter<V : com.lernr.teacher.ui.base.view.MVPView, I : com.lernr.teacher.ui.base.interactor.MVPInteractor> internal constructor(protected var interactor: I?, protected val schedulerProvider: com.lernr.teacher.util.SchedulerProvider, protected val compositeDisposable: CompositeDisposable) : com.lernr.teacher.ui.base.presenter.MVPPresenter<V, I> {

    private var view: V? = null
    private val isViewAttached: Boolean get() = view != null

    override fun onAttach(view: V?) {
        this.view = view
    }

    override fun getView(): V? = view

    override fun onDetach() {
        compositeDisposable.dispose()
        view = null
        interactor = null
    }

}