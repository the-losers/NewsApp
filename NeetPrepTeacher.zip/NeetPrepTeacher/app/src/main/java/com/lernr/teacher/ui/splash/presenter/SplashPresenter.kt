package com.lernr.teacher.ui.splash.presenter

import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

/**
 * Created by jyotidubey on 04/01/18.
 */
class SplashPresenter<V : com.lernr.teacher.ui.splash.view.SplashMVPView, I : com.lernr.teacher.ui.splash.interactor.SplashMVPInteractor> @Inject internal constructor(interactor: I, schedulerProvider: com.lernr.teacher.util.SchedulerProvider, disposable: CompositeDisposable) : com.lernr.teacher.ui.base.presenter.BasePresenter<V, I>(interactor = interactor, schedulerProvider = schedulerProvider, compositeDisposable = disposable), com.lernr.teacher.ui.splash.presenter.SplashMVPPresenter<V, I> {

    override fun onAttach(view: V?) {
        super.onAttach(view)
        feedInDatabase()
    }

    private fun feedInDatabase() = interactor?.let {
        compositeDisposable.add(it.seedQuestions()
                .flatMap { interactor?.seedOptions() }
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe({
                    getView()?.let { decideActivityToOpen() }
                }))
    }

    private fun decideActivityToOpen() = getView()?.let {
        if (isUserLoggedIn())
            it.openMainActivity()
        else
            it.openLoginActivity()
    }

    private fun isUserLoggedIn(): Boolean {
        interactor?.let { return it.isUserLoggedIn() }
        return false
    }

}