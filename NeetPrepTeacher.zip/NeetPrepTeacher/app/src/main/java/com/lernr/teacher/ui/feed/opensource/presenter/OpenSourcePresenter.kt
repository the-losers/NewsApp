package com.lernr.teacher.ui.feed.opensource.presenter

import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

/**
 * Created by jyotidubey on 14/01/18.
 */
class OpenSourcePresenter<V : com.lernr.teacher.ui.feed.opensource.view.OpenSourceMVPView, I : com.lernr.teacher.ui.feed.opensource.interactor.OpenSourceMVPInteractor> @Inject constructor(interactor: I, schedulerProvider: com.lernr.teacher.util.SchedulerProvider, compositeDisposable: CompositeDisposable) : com.lernr.teacher.ui.base.presenter.BasePresenter<V, I>(interactor = interactor, schedulerProvider = schedulerProvider, compositeDisposable = compositeDisposable), com.lernr.teacher.ui.feed.opensource.presenter.OpenSourceMVPPresenter<V, I> {

    override fun onViewPrepared() {
        getView()?.showProgress()
        interactor?.let {
            compositeDisposable.add(it.getOpenSourceList()
                    .compose(schedulerProvider.ioToMainObservableScheduler())
                    .subscribe { openSourceResponse ->
                        getView()?.let {
                            it.hideProgress()
                            it.displayOpenSourceList(openSourceResponse.data)
                        }
                    })
        }

    }
}