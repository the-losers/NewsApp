package com.lernr.teacher.ui.feed.opensource.interactor

import io.reactivex.Observable

/**
 * Created by jyotidubey on 14/01/18.
 */
interface OpenSourceMVPInteractor : com.lernr.teacher.ui.base.interactor.MVPInteractor {

    fun getOpenSourceList(): Observable<com.lernr.teacher.data.network.OpenSourceResponse>
}