package com.lernr.teacher.ui.feed.blog.presenter

import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class BlogPresenter<V : com.lernr.teacher.ui.feed.blog.view.BlogMVPView, I : com.lernr.teacher.ui.feed.blog.interactor.BlogMVPInteractor> @Inject constructor(interactor: I, schedulerProvider: com.lernr.teacher.util.SchedulerProvider, compositeDisposable: CompositeDisposable) : com.lernr.teacher.ui.base.presenter.BasePresenter<V, I>(interactor = interactor, schedulerProvider = schedulerProvider, compositeDisposable = compositeDisposable), com.lernr.teacher.ui.feed.blog.presenter.BlogMVPPresenter<V, I> {

    override fun onViewPrepared() {
        getView()?.showProgress()
        interactor?.let {
            it.getBlogList()
                    .compose(schedulerProvider.ioToMainObservableScheduler())
                    .subscribe { blogResponse ->
                        getView()?.let {
                            it.hideProgress()
                            it.displayBlogList(blogResponse.data)
                        }
                    }
        }
    }
}