package com.lernr.teacher.ui.splash.view

/**
 * Created by jyotidubey on 04/01/18.
 */
interface SplashMVPView : com.lernr.teacher.ui.base.view.MVPView {

    fun showSuccessToast()
    fun showErrorToast()
    fun openMainActivity()
    fun openLoginActivity()
}