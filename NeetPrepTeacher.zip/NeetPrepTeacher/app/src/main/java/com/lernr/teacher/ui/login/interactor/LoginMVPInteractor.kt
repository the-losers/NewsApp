package com.lernr.teacher.ui.login.interactor

import io.reactivex.Observable

/**
 * Created by jyotidubey on 10/01/18.
 */
interface LoginMVPInteractor : com.lernr.teacher.ui.base.interactor.MVPInteractor {

    fun doServerLoginApiCall(email: String, password: String): Observable<com.lernr.teacher.data.network.LoginResponse>

    fun doFBLoginApiCall(): Observable<com.lernr.teacher.data.network.LoginResponse>

    fun doGoogleLoginApiCall(): Observable<com.lernr.teacher.data.network.LoginResponse>

    fun updateUserInSharedPref(loginResponse: com.lernr.teacher.data.network.LoginResponse, loggedInMode: com.lernr.teacher.util.AppConstants.LoggedInMode)

}