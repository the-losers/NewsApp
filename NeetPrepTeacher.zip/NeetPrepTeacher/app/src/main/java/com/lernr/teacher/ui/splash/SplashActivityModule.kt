package com.lernr.teacher.ui.splash

import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 06/01/18.
 */
@Module
class SplashActivityModule {

    @Provides
    internal fun provideSplashInteractor(splashInteractor: com.lernr.teacher.ui.splash.interactor.SplashInteractor): com.lernr.teacher.ui.splash.interactor.SplashMVPInteractor = splashInteractor

    @Provides
    internal fun provideSplashPresenter(splashPresenter: com.lernr.teacher.ui.splash.presenter.SplashPresenter<com.lernr.teacher.ui.splash.view.SplashMVPView, com.lernr.teacher.ui.splash.interactor.SplashMVPInteractor>)
            : com.lernr.teacher.ui.splash.presenter.SplashMVPPresenter<com.lernr.teacher.ui.splash.view.SplashMVPView, com.lernr.teacher.ui.splash.interactor.SplashMVPInteractor> = splashPresenter
}