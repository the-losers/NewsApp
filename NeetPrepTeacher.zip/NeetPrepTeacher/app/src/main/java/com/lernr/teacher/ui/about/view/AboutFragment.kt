package com.lernr.teacher.ui.about.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.lernr.teacher.R

import kotlinx.android.synthetic.main.fragment_about.*

class AboutFragment : com.lernr.teacher.ui.base.view.BaseFragment() {

    companion object {

        internal val TAG = "AboutFragment"

        fun newInstance(): com.lernr.teacher.ui.about.view.AboutFragment {
            return com.lernr.teacher.ui.about.view.AboutFragment()
        }

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
            inflater.inflate(R.layout.fragment_about, container, false)

    override fun setUp() = navBackBtn.setOnClickListener { getBaseActivity()?.onFragmentDetached(com.lernr.teacher.ui.about.view.AboutFragment.Companion.TAG) }

}