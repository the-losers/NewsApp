package com.lernr.teacher.ui.login.interactor

import javax.inject.Inject

/**
 * Created by jyotidubey on 10/01/18.
 */
class LoginInteractor @Inject internal constructor(preferenceHelper: com.lernr.teacher.data.preferences.PreferenceHelper, apiHelper: com.lernr.teacher.data.network.ApiHelper) : com.lernr.teacher.ui.base.interactor.BaseInteractor(preferenceHelper, apiHelper), com.lernr.teacher.ui.login.interactor.LoginMVPInteractor {

    override fun doGoogleLoginApiCall() =
            apiHelper.performGoogleLogin(com.lernr.teacher.data.network.LoginRequest.GoogleLoginRequest("test1", "test1"))

    override fun doFBLoginApiCall() =
            apiHelper.performFBLogin(com.lernr.teacher.data.network.LoginRequest.FacebookLoginRequest("test3", "test4"))


    override fun doServerLoginApiCall(email: String, password: String) =
            apiHelper.performServerLogin(com.lernr.teacher.data.network.LoginRequest.ServerLoginRequest(email = email, password = password))


    override fun updateUserInSharedPref(loginResponse: com.lernr.teacher.data.network.LoginResponse, loggedInMode: com.lernr.teacher.util.AppConstants.LoggedInMode) =
            preferenceHelper.let {
                it.setCurrentUserId(loginResponse.userId)
                it.setAccessToken(loginResponse.accessToken)
                it.setCurrentUserLoggedInMode(loggedInMode)
            }
}