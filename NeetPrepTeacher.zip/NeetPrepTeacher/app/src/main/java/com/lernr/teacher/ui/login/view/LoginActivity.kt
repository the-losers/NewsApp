package com.lernr.teacher.ui.login.view

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.lernr.teacher.R

import kotlinx.android.synthetic.main.activity_login.*
import javax.inject.Inject

/**
 * Created by jyotidubey on 10/01/18.
 */
class LoginActivity : com.lernr.teacher.ui.base.view.BaseActivity(), com.lernr.teacher.ui.login.view.LoginMVPView {

    @Inject
    internal lateinit var presenter: com.lernr.teacher.ui.login.presenter.LoginMVPPresenter<com.lernr.teacher.ui.login.view.LoginMVPView, com.lernr.teacher.ui.login.interactor.LoginMVPInteractor>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        presenter.onAttach(this)
        setOnClickListeners()
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    override fun onFragmentDetached(tag: String) {
    }

    override fun onFragmentAttached() {
    }

    override fun showValidationMessage(errorCode: Int) {
        when (errorCode) {
            com.lernr.teacher.util.AppConstants.EMPTY_EMAIL_ERROR -> Toast.makeText(this, getString(R.string.empty_email_error_message), Toast.LENGTH_LONG).show()
            com.lernr.teacher.util.AppConstants.INVALID_EMAIL_ERROR -> Toast.makeText(this, getString(R.string.invalid_email_error_message), Toast.LENGTH_LONG).show()
            com.lernr.teacher.util.AppConstants.EMPTY_PASSWORD_ERROR -> Toast.makeText(this, getString(R.string.empty_password_error_message), Toast.LENGTH_LONG).show()
            com.lernr.teacher.util.AppConstants.LOGIN_FAILURE -> Toast.makeText(this, getString(R.string.login_failure), Toast.LENGTH_LONG).show()
        }
    }

    override fun openMainActivity() {
        val intent = Intent(this, com.lernr.teacher.ui.main.view.MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun setOnClickListeners() {
        btnServerLogin.setOnClickListener { presenter.onServerLoginClicked(et_email.text.toString(), et_password.text.toString()) }
        ibGoogleLogin.setOnClickListener { presenter.onGoogleLoginClicked() }
        ibFbLogin.setOnClickListener { presenter.onFBLoginClicked() }
    }
}