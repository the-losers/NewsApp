package com.lernr.teacher.ui.feed.blog.view

/**
 * Created by jyotidubey on 13/01/18.
 */
interface BlogMVPView : com.lernr.teacher.ui.base.view.MVPView {

    fun displayBlogList(blogs: List<com.lernr.teacher.data.network.Blog>?) : Unit?

}