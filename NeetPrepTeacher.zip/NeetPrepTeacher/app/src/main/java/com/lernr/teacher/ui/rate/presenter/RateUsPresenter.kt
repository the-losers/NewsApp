package com.lernr.teacher.ui.rate.presenter

import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

/**
 * Created by jyotidubey on 15/01/18.
 */
class RateUsPresenter<V : com.lernr.teacher.ui.rate.view.RateUsDialogMVPView, I : com.lernr.teacher.ui.rate.interactor.RateUsMVPInterator> @Inject internal constructor(interator: I, schedulerProvider: com.lernr.teacher.util.SchedulerProvider, compositeDisposable: CompositeDisposable) : com.lernr.teacher.ui.base.presenter.BasePresenter<V, I>(interactor = interator, schedulerProvider = schedulerProvider, compositeDisposable = compositeDisposable), com.lernr.teacher.ui.rate.presenter.RateUsMVPPresenter<V, I> {

    override fun onLaterOptionClicked() = getView()?.let { it.dismissDialog() }

    override fun onSubmitOptionClicked() = interactor?.let {
        it.submitRating()
        getView()?.let {
            it.showRatingSubmissionSuccessMessage()
            it.dismissDialog()
        }
    }
}
