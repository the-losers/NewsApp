package com.lernr.teacher.ui.feed.opensource.view

import android.os.Bundle
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.lernr.teacher.R

import kotlinx.android.synthetic.main.fragment_open_source.*
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class OpenSourceFragment : com.lernr.teacher.ui.base.view.BaseFragment(), com.lernr.teacher.ui.feed.opensource.view.OpenSourceMVPView {

    companion object {

        fun newInstance(): com.lernr.teacher.ui.feed.opensource.view.OpenSourceFragment {
            return com.lernr.teacher.ui.feed.opensource.view.OpenSourceFragment()
        }

    }

    @Inject
    internal lateinit var openSourceAdapter: com.lernr.teacher.ui.feed.opensource.view.OpenSourceAdapter
    @Inject
    internal lateinit var layoutManager: LinearLayoutManager
    @Inject
    internal lateinit var presenter: com.lernr.teacher.ui.feed.opensource.presenter.OpenSourceMVPPresenter<com.lernr.teacher.ui.feed.opensource.view.OpenSourceMVPView, com.lernr.teacher.ui.feed.opensource.interactor.OpenSourceMVPInteractor>


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_open_source, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun setUp() {
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        repo_recycler_view.layoutManager = layoutManager
        repo_recycler_view.itemAnimator = DefaultItemAnimator()
        repo_recycler_view.adapter = openSourceAdapter
        presenter.onViewPrepared()
    }

    override fun displayOpenSourceList(OpenSources: List<com.lernr.teacher.data.network.OpenSource>?) {
        OpenSources?.let {
            openSourceAdapter.addOpenSourcesToList(it)
        }
    }

    override fun onDestroyView() {
        presenter.onDetach()
        super.onDestroyView()
    }

}