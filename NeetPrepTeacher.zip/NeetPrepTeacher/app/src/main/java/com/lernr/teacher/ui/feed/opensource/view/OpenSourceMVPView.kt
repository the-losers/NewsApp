package com.lernr.teacher.ui.feed.opensource.view

/**
 * Created by jyotidubey on 14/01/18.
 */
interface OpenSourceMVPView : com.lernr.teacher.ui.base.view.MVPView {
    fun displayOpenSourceList(blogs: List<com.lernr.teacher.data.network.OpenSource>?)

}