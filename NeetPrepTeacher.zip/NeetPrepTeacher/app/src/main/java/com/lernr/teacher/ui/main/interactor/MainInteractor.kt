package com.lernr.teacher.ui.main.interactor

import javax.inject.Inject

/**
 * Created by jyotidubey on 08/01/18.
 */
class MainInteractor @Inject internal constructor(private val questionRepoHelper: com.lernr.teacher.data.database.repository.questions.QuestionRepo, private val optionsRepoHelper: com.lernr.teacher.data.database.repository.options.OptionsRepo, preferenceHelper: com.lernr.teacher.data.preferences.PreferenceHelper, apiHelper: com.lernr.teacher.data.network.ApiHelper) : com.lernr.teacher.ui.base.interactor.BaseInteractor(preferenceHelper = preferenceHelper, apiHelper = apiHelper), com.lernr.teacher.ui.main.interactor.MainMVPInteractor {

    override fun getQuestionCardData() = questionRepoHelper.loadQuestions()
            .flatMapIterable { question -> question }
            .flatMapSingle { question -> getQuestionCards(question) }
            .toList()

    override fun getUserDetails() = Pair(preferenceHelper.getCurrentUserName(),
            preferenceHelper.getCurrentUserEmail())

    override fun makeLogoutApiCall() = apiHelper.performLogoutApiCall()

    private fun getQuestionCards(question: com.lernr.teacher.data.database.repository.questions.Question) = optionsRepoHelper.loadOptions(question.id)
            .map { options -> createQuestionCard(options, question) }

    private fun createQuestionCard(options: List<com.lernr.teacher.data.database.repository.options.Options>, question: com.lernr.teacher.data.database.repository.questions.Question) = com.lernr.teacher.ui.main.interactor.QuestionCardData(options, question)

}


