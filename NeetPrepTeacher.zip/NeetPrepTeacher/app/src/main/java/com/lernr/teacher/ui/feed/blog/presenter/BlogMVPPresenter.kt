package com.lernr.teacher.ui.feed.blog.presenter

/**
 * Created by jyotidubey on 13/01/18.
 */
interface BlogMVPPresenter<V : com.lernr.teacher.ui.feed.blog.view.BlogMVPView, I : com.lernr.teacher.ui.feed.blog.interactor.BlogMVPInteractor> : com.lernr.teacher.ui.base.presenter.MVPPresenter<V, I> {

    fun onViewPrepared()
}