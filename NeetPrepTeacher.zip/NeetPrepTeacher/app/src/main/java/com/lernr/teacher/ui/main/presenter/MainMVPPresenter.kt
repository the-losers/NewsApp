package com.lernr.teacher.ui.main.presenter

/**
 * Created by jyotidubey on 08/01/18.
 */
interface MainMVPPresenter<V : com.lernr.teacher.ui.main.view.MainMVPView, I : com.lernr.teacher.ui.main.interactor.MainMVPInteractor> : com.lernr.teacher.ui.base.presenter.MVPPresenter<V, I> {

    fun refreshQuestionCards(): Boolean?
    fun onDrawerOptionAboutClick() : Unit?
    fun onDrawerOptionRateUsClick(): Unit?
    fun onDrawerOptionFeedClick(): Unit?
    fun onDrawerOptionLogoutClick()

}