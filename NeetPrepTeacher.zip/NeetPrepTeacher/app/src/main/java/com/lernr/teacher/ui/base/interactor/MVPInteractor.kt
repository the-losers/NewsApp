package com.lernr.teacher.ui.base.interactor


interface MVPInteractor {

    fun isUserLoggedIn(): Boolean

    fun performUserLogout()

}