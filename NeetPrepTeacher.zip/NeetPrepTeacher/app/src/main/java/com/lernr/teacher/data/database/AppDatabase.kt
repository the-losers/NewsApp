package com.lernr.teacher.data.database

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase


@Database(entities = [(com.lernr.teacher.data.database.repository.questions.Question::class), (com.lernr.teacher.data.database.repository.options.Options::class)], version = 1)
abstract class AppDatabase : RoomDatabase() {

    abstract fun optionsDao(): com.lernr.teacher.data.database.repository.options.OptionsDao

    abstract fun questionsDao(): com.lernr.teacher.data.database.repository.questions.QuestionsDao

}