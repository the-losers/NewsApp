package com.lernr.teacher.ui.feed.blog

import android.support.v7.widget.LinearLayoutManager
import dagger.Module
import dagger.Provides
import java.util.*

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
class BlogFragmentModule {

    @Provides
    internal fun provideBlogInteractor(interactor: com.lernr.teacher.ui.feed.blog.interactor.BlogInteractor): com.lernr.teacher.ui.feed.blog.interactor.BlogMVPInteractor = interactor

    @Provides
    internal fun provideBlogPresenter(presenter: com.lernr.teacher.ui.feed.blog.presenter.BlogPresenter<com.lernr.teacher.ui.feed.blog.view.BlogMVPView, com.lernr.teacher.ui.feed.blog.interactor.BlogMVPInteractor>)
            : com.lernr.teacher.ui.feed.blog.presenter.BlogMVPPresenter<com.lernr.teacher.ui.feed.blog.view.BlogMVPView, com.lernr.teacher.ui.feed.blog.interactor.BlogMVPInteractor> = presenter

    @Provides
    internal fun provideBlogAdapter(): com.lernr.teacher.ui.feed.blog.view.BlogAdapter = com.lernr.teacher.ui.feed.blog.view.BlogAdapter(ArrayList())

    @Provides
    internal fun provideLinearLayoutManager(fragment: com.lernr.teacher.ui.feed.blog.view.BlogFragment): LinearLayoutManager = LinearLayoutManager(fragment.activity)

}