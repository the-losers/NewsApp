package com.lernr.teacher.di

import javax.inject.Qualifier

/**
 * Created by jyotidubey on 22/01/18.
 */
@Qualifier
@Retention annotation class ApiKeyInfo