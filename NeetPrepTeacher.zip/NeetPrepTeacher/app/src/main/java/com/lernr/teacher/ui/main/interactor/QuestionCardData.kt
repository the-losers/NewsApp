package com.lernr.teacher.ui.main.interactor

/**
 * Created by jyotidubey on 08/01/18.
 */
data class QuestionCardData(val option: List<com.lernr.teacher.data.database.repository.options.Options>, val question: com.lernr.teacher.data.database.repository.questions.Question)