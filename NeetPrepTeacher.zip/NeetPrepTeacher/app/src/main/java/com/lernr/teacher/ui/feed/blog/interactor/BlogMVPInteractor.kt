package com.lernr.teacher.ui.feed.blog.interactor

import io.reactivex.Observable

/**
 * Created by jyotidubey on 13/01/18.
 */
interface BlogMVPInteractor : com.lernr.teacher.ui.base.interactor.MVPInteractor {

    fun getBlogList(): Observable<com.lernr.teacher.data.network.BlogResponse>

}