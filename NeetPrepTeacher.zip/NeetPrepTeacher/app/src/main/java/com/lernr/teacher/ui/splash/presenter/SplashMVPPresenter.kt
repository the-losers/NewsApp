package com.lernr.teacher.ui.splash.presenter

/**
 * Created by jyotidubey on 04/01/18.
 */
interface SplashMVPPresenter<V : com.lernr.teacher.ui.splash.view.SplashMVPView, I : com.lernr.teacher.ui.splash.interactor.SplashMVPInteractor> : com.lernr.teacher.ui.base.presenter.MVPPresenter<V, I>