package com.lernr.teacher.ui.splash.interactor

import io.reactivex.Observable

/**
 * Created by jyotidubey on 04/01/18.
 */
interface SplashMVPInteractor : com.lernr.teacher.ui.base.interactor.MVPInteractor {

    fun seedQuestions(): Observable<Boolean>
    fun seedOptions(): Observable<Boolean>
    fun getQuestion() : Observable<List<com.lernr.teacher.data.database.repository.questions.Question>>
}