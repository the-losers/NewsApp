package com.lernr.teacher.ui.rate

import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 15/01/18.
 */
@Module
class RateUsFragmentModule {

    @Provides
    internal fun provideRateUsInteractor(interactor: com.lernr.teacher.ui.rate.interactor.RateUsInteractor): com.lernr.teacher.ui.rate.interactor.RateUsMVPInterator = interactor

    @Provides
    internal fun provideRateUsPresenter(presenter: com.lernr.teacher.ui.rate.presenter.RateUsPresenter<com.lernr.teacher.ui.rate.view.RateUsDialogMVPView, com.lernr.teacher.ui.rate.interactor.RateUsMVPInterator>)
            : com.lernr.teacher.ui.rate.presenter.RateUsMVPPresenter<com.lernr.teacher.ui.rate.view.RateUsDialogMVPView, com.lernr.teacher.ui.rate.interactor.RateUsMVPInterator> = presenter
}