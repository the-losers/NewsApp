package com.lernr.teacher.ui.rate.view

/**
 * Created by jyotidubey on 14/01/18.
 */
interface RateUsDialogMVPView : com.lernr.teacher.ui.base.view.MVPView {

    fun dismissDialog()
    fun showRatingSubmissionSuccessMessage()
}