package com.lernr.teacher.ui.feed.opensource

import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
internal abstract class OpenSourceFragmentProvider {

    @ContributesAndroidInjector(modules = [(com.lernr.teacher.ui.feed.opensource.OpenSourceFragmentModule::class)])
    internal abstract fun provideBlogFragmentFactory(): com.lernr.teacher.ui.feed.opensource.view.OpenSourceFragment

}