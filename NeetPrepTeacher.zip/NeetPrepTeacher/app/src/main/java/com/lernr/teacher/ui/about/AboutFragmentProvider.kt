package com.lernr.teacher.ui.about

import dagger.Module
import dagger.android.ContributesAndroidInjector


@Module
abstract class AboutFragmentProvider {

    @ContributesAndroidInjector
    abstract internal fun provideAboutFragment(): com.lernr.teacher.ui.about.view.AboutFragment

}