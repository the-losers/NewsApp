package com.lernr.teacher.ui.feed.blog.interactor

import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class BlogInteractor @Inject internal constructor(preferenceHelper: com.lernr.teacher.data.preferences.PreferenceHelper, apiHelper: com.lernr.teacher.data.network.ApiHelper) : com.lernr.teacher.ui.base.interactor.BaseInteractor(preferenceHelper, apiHelper), com.lernr.teacher.ui.feed.blog.interactor.BlogMVPInteractor {

    override fun getBlogList() = apiHelper.getBlogApiCall()

}