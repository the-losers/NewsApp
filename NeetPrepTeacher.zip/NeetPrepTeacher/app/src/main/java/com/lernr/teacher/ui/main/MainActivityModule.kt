package com.lernr.teacher.ui.main

import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 09/01/18.
 */
@Module
class MainActivityModule {

    @Provides
    internal fun provideMainInteractor(mainInteractor: com.lernr.teacher.ui.main.interactor.MainInteractor): com.lernr.teacher.ui.main.interactor.MainMVPInteractor = mainInteractor

    @Provides
    internal fun provideMainPresenter(mainPresenter: com.lernr.teacher.ui.main.presenter.MainPresenter<com.lernr.teacher.ui.main.view.MainMVPView, com.lernr.teacher.ui.main.interactor.MainMVPInteractor>)
            : com.lernr.teacher.ui.main.presenter.MainMVPPresenter<com.lernr.teacher.ui.main.view.MainMVPView, com.lernr.teacher.ui.main.interactor.MainMVPInteractor> = mainPresenter

}