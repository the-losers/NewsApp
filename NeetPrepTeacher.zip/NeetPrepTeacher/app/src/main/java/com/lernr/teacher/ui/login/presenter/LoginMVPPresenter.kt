package com.lernr.teacher.ui.login.presenter

/**
 * Created by jyotidubey on 10/01/18.
 */
interface LoginMVPPresenter<V : com.lernr.teacher.ui.login.view.LoginMVPView, I : com.lernr.teacher.ui.login.interactor.LoginMVPInteractor> : com.lernr.teacher.ui.base.presenter.MVPPresenter<V, I> {

    fun onServerLoginClicked(email: String, password: String)
    fun onFBLoginClicked()
    fun onGoogleLoginClicked()

}