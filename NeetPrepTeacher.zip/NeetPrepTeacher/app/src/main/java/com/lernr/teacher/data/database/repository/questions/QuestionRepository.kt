package com.lernr.teacher.data.database.repository.questions

import io.reactivex.Observable
import javax.inject.Inject

/**
 * Created by jyotidubey on 06/01/18.
 */
class QuestionRepository @Inject internal constructor(private val questionsDao: com.lernr.teacher.data.database.repository.questions.QuestionsDao) : com.lernr.teacher.data.database.repository.questions.QuestionRepo {

    override fun isQuestionsRepoEmpty(): Observable<Boolean> = Observable.fromCallable({ questionsDao.loadAll().isEmpty() })

    override fun insertQuestions(questions: List<com.lernr.teacher.data.database.repository.questions.Question>): Observable<Boolean> {
        questionsDao.insertAll(questions)
        return Observable.just(true)
    }

    override fun loadQuestions(): Observable<List<com.lernr.teacher.data.database.repository.questions.Question>> = Observable.fromCallable({ questionsDao.loadAll() })
}


