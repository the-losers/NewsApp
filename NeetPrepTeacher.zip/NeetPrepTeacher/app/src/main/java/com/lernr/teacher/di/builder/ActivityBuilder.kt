package com.lernr.teacher.di.builder

import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by jyotidubey on 05/01/18.
 */
@Module
abstract class ActivityBuilder {

    @ContributesAndroidInjector(modules = [(com.lernr.teacher.ui.splash.SplashActivityModule::class)])
    abstract fun bindSplashActivity(): com.lernr.teacher.ui.splash.view.SplashMVPActivity

    @ContributesAndroidInjector(modules = [(com.lernr.teacher.ui.main.MainActivityModule::class), (com.lernr.teacher.ui.rate.RateUsDialogFragmentProvider::class), (com.lernr.teacher.ui.about.AboutFragmentProvider::class)])
    abstract fun bindMainActivity(): com.lernr.teacher.ui.main.view.MainActivity

    @ContributesAndroidInjector(modules = [(com.lernr.teacher.ui.login.LoginActivityModule::class)])
    abstract fun bindLoginActivity(): com.lernr.teacher.ui.login.view.LoginActivity

    @ContributesAndroidInjector(modules = [(com.lernr.teacher.ui.feed.blog.BlogFragmentProvider::class), (com.lernr.teacher.ui.feed.opensource.OpenSourceFragmentProvider::class)])
    abstract fun bindFeedActivity(): com.lernr.teacher.ui.feed.view.FeedActivity

}