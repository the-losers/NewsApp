package com.lernr.teacher.ui.rate.presenter

/**
 * Created by jyotidubey on 15/01/18.
 */
interface RateUsMVPPresenter<V : com.lernr.teacher.ui.rate.view.RateUsDialogMVPView, I : com.lernr.teacher.ui.rate.interactor.RateUsMVPInterator> : com.lernr.teacher.ui.base.presenter.MVPPresenter<V, I> {

    fun onLaterOptionClicked() : Unit?
    fun onSubmitOptionClicked() : Unit?
}