package com.lernr.teacher.data.network

import com.rx2androidnetworking.Rx2AndroidNetworking
import io.reactivex.Observable
import javax.inject.Inject

/**
 * Created by jyotidubey on 04/01/18.
 */
class AppApiHelper @Inject constructor(private val apiHeader: com.lernr.teacher.data.network.ApiHeader) : com.lernr.teacher.data.network.ApiHelper {

    override fun performServerLogin(request: com.lernr.teacher.data.network.LoginRequest.ServerLoginRequest): Observable<com.lernr.teacher.data.network.LoginResponse> =
            Rx2AndroidNetworking.post(com.lernr.teacher.data.network.ApiEndPoint.ENDPOINT_SERVER_LOGIN)
                    .addHeaders(apiHeader.publicApiHeader)
                    .addBodyParameter(request)
                    .build()
                    .getObjectObservable(com.lernr.teacher.data.network.LoginResponse::class.java)

    override fun performFBLogin(request: com.lernr.teacher.data.network.LoginRequest.FacebookLoginRequest): Observable<com.lernr.teacher.data.network.LoginResponse> =
            Rx2AndroidNetworking.post(com.lernr.teacher.data.network.ApiEndPoint.ENDPOINT_FACEBOOK_LOGIN)
                    .addHeaders(apiHeader.publicApiHeader)
                    .addBodyParameter(request)
                    .build()
                    .getObjectObservable(com.lernr.teacher.data.network.LoginResponse::class.java)

    override fun performGoogleLogin(request: com.lernr.teacher.data.network.LoginRequest.GoogleLoginRequest): Observable<com.lernr.teacher.data.network.LoginResponse> =
            Rx2AndroidNetworking.post(com.lernr.teacher.data.network.ApiEndPoint.ENDPOINT_GOOGLE_LOGIN)
                    .addHeaders(apiHeader.publicApiHeader)
                    .addBodyParameter(request)
                    .build()
                    .getObjectObservable(com.lernr.teacher.data.network.LoginResponse::class.java)

    override fun performLogoutApiCall(): Observable<com.lernr.teacher.data.network.LogoutResponse> =
            Rx2AndroidNetworking.post(com.lernr.teacher.data.network.ApiEndPoint.ENDPOINT_LOGOUT)
                    .addHeaders(apiHeader.protectedApiHeader)
                    .build()
                    .getObjectObservable(com.lernr.teacher.data.network.LogoutResponse::class.java)

    override fun getBlogApiCall(): Observable<com.lernr.teacher.data.network.BlogResponse> =
            Rx2AndroidNetworking.get(com.lernr.teacher.data.network.ApiEndPoint.ENDPOINT_BLOG)
                    .addHeaders(apiHeader.protectedApiHeader)
                    .build()
                    .getObjectObservable(com.lernr.teacher.data.network.BlogResponse::class.java)

    override fun getOpenSourceApiCall(): Observable<com.lernr.teacher.data.network.OpenSourceResponse> =
            Rx2AndroidNetworking.get(com.lernr.teacher.data.network.ApiEndPoint.ENDPOINT_OPEN_SOURCE)
                    .addHeaders(apiHeader.protectedApiHeader)
                    .build()
                    .getObjectObservable(com.lernr.teacher.data.network.OpenSourceResponse::class.java)

}