package com.lernr.teacher.ui.rate.interactor

/**
 * Created by jyotidubey on 15/01/18.
 */
interface RateUsMVPInterator : com.lernr.teacher.ui.base.interactor.MVPInteractor {

    fun submitRating()
}