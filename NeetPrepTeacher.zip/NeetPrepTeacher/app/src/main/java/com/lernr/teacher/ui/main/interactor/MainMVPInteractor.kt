package com.lernr.teacher.ui.main.interactor

import io.reactivex.Observable
import io.reactivex.Single

/**
 * Created by jyotidubey on 08/01/18.
 */
interface MainMVPInteractor : com.lernr.teacher.ui.base.interactor.MVPInteractor {

    fun getQuestionCardData(): Single<List<com.lernr.teacher.ui.main.interactor.QuestionCardData>>
    fun getUserDetails() : Pair<String?,String?>
    fun makeLogoutApiCall() : Observable<com.lernr.teacher.data.network.LogoutResponse>
}