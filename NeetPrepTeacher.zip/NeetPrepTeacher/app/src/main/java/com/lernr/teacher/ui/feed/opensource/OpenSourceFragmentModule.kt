package com.lernr.teacher.ui.feed.opensource

import android.support.v7.widget.LinearLayoutManager
import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
class OpenSourceFragmentModule {

    @Provides
    internal fun provideOpenSourceInteractor(interactor: com.lernr.teacher.ui.feed.opensource.interactor.OpenSourceInteractor): com.lernr.teacher.ui.feed.opensource.interactor.OpenSourceMVPInteractor = interactor

    @Provides
    internal fun provideOpenSourcePresenter(presenter: com.lernr.teacher.ui.feed.opensource.presenter.OpenSourcePresenter<com.lernr.teacher.ui.feed.opensource.view.OpenSourceMVPView, com.lernr.teacher.ui.feed.opensource.interactor.OpenSourceMVPInteractor>)
            : com.lernr.teacher.ui.feed.opensource.presenter.OpenSourceMVPPresenter<com.lernr.teacher.ui.feed.opensource.view.OpenSourceMVPView, com.lernr.teacher.ui.feed.opensource.interactor.OpenSourceMVPInteractor> = presenter

    @Provides
    internal fun provideOpenSourceAdapter(): com.lernr.teacher.ui.feed.opensource.view.OpenSourceAdapter = com.lernr.teacher.ui.feed.opensource.view.OpenSourceAdapter(ArrayList())

    @Provides
    internal fun provideLinearLayoutManager(fragment: com.lernr.teacher.ui.feed.opensource.view.OpenSourceFragment): LinearLayoutManager = LinearLayoutManager(fragment.activity)


}