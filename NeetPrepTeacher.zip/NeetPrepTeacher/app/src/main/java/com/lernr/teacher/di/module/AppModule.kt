package com.lernr.teacher.di.module

import android.app.Application
import android.arch.persistence.room.Room
import android.content.Context
import com.lernr.teacher.BuildConfig

import dagger.Module
import dagger.Provides
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Singleton

/**
 * Created by jyotidubey on 05/01/18.
 */
@Module
class AppModule {

    @Provides
    @Singleton
    internal fun provideContext(application: Application): Context = application

    @Provides
    @Singleton
    internal fun provideAppDatabase(context: Context): com.lernr.teacher.data.database.AppDatabase =
            Room.databaseBuilder(context, com.lernr.teacher.data.database.AppDatabase::class.java, com.lernr.teacher.util.AppConstants.APP_DB_NAME).build()

    @Provides
    @com.lernr.teacher.di.ApiKeyInfo
    internal fun provideApiKey(): String = BuildConfig.API_KEY

    @Provides
    @com.lernr.teacher.di.PreferenceInfo
    internal fun provideprefFileName(): String = com.lernr.teacher.util.AppConstants.PREF_NAME

    @Provides
    @Singleton
    internal fun providePrefHelper(appPreferenceHelper: com.lernr.teacher.data.preferences.AppPreferenceHelper): com.lernr.teacher.data.preferences.PreferenceHelper = appPreferenceHelper

    @Provides
    @Singleton
    internal fun provideProtectedApiHeader(@com.lernr.teacher.di.ApiKeyInfo apiKey: String, preferenceHelper: com.lernr.teacher.data.preferences.PreferenceHelper)
            : com.lernr.teacher.data.network.ApiHeader.ProtectedApiHeader = com.lernr.teacher.data.network.ApiHeader.ProtectedApiHeader(apiKey = apiKey,
            userId = preferenceHelper.getCurrentUserId(),
            accessToken = preferenceHelper.getAccessToken())

    @Provides
    @Singleton
    internal fun provideApiHelper(appApiHelper: com.lernr.teacher.data.network.AppApiHelper): com.lernr.teacher.data.network.ApiHelper = appApiHelper

    @Provides
    @Singleton
    internal fun provideQuestionRepoHelper(appDatabase: com.lernr.teacher.data.database.AppDatabase): com.lernr.teacher.data.database.repository.questions.QuestionRepo = com.lernr.teacher.data.database.repository.questions.QuestionRepository(appDatabase.questionsDao())

    @Provides
    @Singleton
    internal fun provideOptionsRepoHelper(appDatabase: com.lernr.teacher.data.database.AppDatabase): com.lernr.teacher.data.database.repository.options.OptionsRepo = com.lernr.teacher.data.database.repository.options.OptionsRepository(appDatabase.optionsDao())

    @Provides
    internal fun provideCompositeDisposable(): CompositeDisposable = CompositeDisposable()

    @Provides
    internal fun provideSchedulerProvider(): com.lernr.teacher.util.SchedulerProvider = com.lernr.teacher.util.SchedulerProvider()


}