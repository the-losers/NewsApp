package com.lernr.teacher.ui.login.view

/**
 * Created by jyotidubey on 10/01/18.
 */
interface LoginMVPView : com.lernr.teacher.ui.base.view.MVPView {

    fun showValidationMessage(errorCode: Int)
    fun openMainActivity()
}