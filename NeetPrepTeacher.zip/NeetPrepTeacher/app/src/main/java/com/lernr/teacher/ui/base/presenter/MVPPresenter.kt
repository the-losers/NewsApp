package com.lernr.teacher.ui.base.presenter

interface MVPPresenter<V : com.lernr.teacher.ui.base.view.MVPView, I : com.lernr.teacher.ui.base.interactor.MVPInteractor> {

    fun onAttach(view: V?)

    fun onDetach()

    fun getView(): V?

}