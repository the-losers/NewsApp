package com.lernr.teacher.ui.splash.interactor

import android.content.Context
import com.google.gson.GsonBuilder
import com.google.gson.internal.`$Gson$Types`
import io.reactivex.Observable
import javax.inject.Inject

/**
 * Created by jyotidubey on 04/01/18.
 */
class SplashInteractor @Inject constructor(private val mContext: Context, private val questionRepoHelper: com.lernr.teacher.data.database.repository.questions.QuestionRepo, private val optionsRepoHelper: com.lernr.teacher.data.database.repository.options.OptionsRepo, preferenceHelper: com.lernr.teacher.data.preferences.PreferenceHelper, apiHelper: com.lernr.teacher.data.network.ApiHelper) : com.lernr.teacher.ui.base.interactor.BaseInteractor(preferenceHelper, apiHelper), com.lernr.teacher.ui.splash.interactor.SplashMVPInteractor {

    override fun getQuestion(): Observable<List<com.lernr.teacher.data.database.repository.questions.Question>> {
        return questionRepoHelper.loadQuestions()
    }

    override fun seedQuestions(): Observable<Boolean> {
        val builder = GsonBuilder().excludeFieldsWithoutExposeAnnotation()
        val gson = builder.create()
        return questionRepoHelper.isQuestionsRepoEmpty().concatMap { isEmpty ->
            if (isEmpty) {
                val type = `$Gson$Types`.newParameterizedTypeWithOwner(null, List::class.java, com.lernr.teacher.data.database.repository.questions.Question::class.java)
                val questionList = gson.fromJson<List<com.lernr.teacher.data.database.repository.questions.Question>>(
                        com.lernr.teacher.util.FileUtils.loadJSONFromAsset(
                                mContext,
                                com.lernr.teacher.util.AppConstants.SEED_DATABASE_QUESTIONS),
                        type)
                questionRepoHelper.insertQuestions(questionList)
            } else
                Observable.just(false)
        }
    }

    override fun seedOptions(): Observable<Boolean> {
        val builder = GsonBuilder().excludeFieldsWithoutExposeAnnotation()
        val gson = builder.create()
        return optionsRepoHelper.isOptionsRepoEmpty().concatMap { isEmpty ->
            if (isEmpty) {
                val type = `$Gson$Types`.newParameterizedTypeWithOwner(null, List::class.java, com.lernr.teacher.data.database.repository.options.Options::class.java)
                val optionsList = gson.fromJson<List<com.lernr.teacher.data.database.repository.options.Options>>(
                        com.lernr.teacher.util.FileUtils.loadJSONFromAsset(
                                mContext,
                                com.lernr.teacher.util.AppConstants.SEED_DATABASE_OPTIONS),
                        type)
                optionsRepoHelper.insertOptions(optionsList)
            } else
                Observable.just(false)
        }
    }
}