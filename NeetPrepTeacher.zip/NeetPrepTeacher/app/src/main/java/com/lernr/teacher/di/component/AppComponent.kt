package com.lernr.teacher.di.component

import android.app.Application
import dagger.BindsInstance
import dagger.Component
import dagger.android.AndroidInjectionModule
import javax.inject.Singleton

/**
 * Created by jyotidubey on 05/01/18.
 */
@Singleton
@Component(modules = [(AndroidInjectionModule::class), (com.lernr.teacher.di.module.AppModule::class), (com.lernr.teacher.di.builder.ActivityBuilder::class)])
interface AppComponent {

    @Component.Builder
    interface Builder {

        @BindsInstance
        fun application(application: Application): com.lernr.teacher.di.component.AppComponent.Builder

        fun build(): com.lernr.teacher.di.component.AppComponent
    }

    fun inject(app: com.lernr.teacher.MvpApp)

}