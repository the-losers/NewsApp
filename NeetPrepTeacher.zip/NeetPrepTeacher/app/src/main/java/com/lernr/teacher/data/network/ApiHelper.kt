package com.lernr.teacher.data.network

import io.reactivex.Observable

/**
 * Created by jyotidubey on 04/01/18.
 */
interface ApiHelper {

    fun performServerLogin(request: com.lernr.teacher.data.network.LoginRequest.ServerLoginRequest): Observable<com.lernr.teacher.data.network.LoginResponse>

    fun performFBLogin(request: com.lernr.teacher.data.network.LoginRequest.FacebookLoginRequest): Observable<com.lernr.teacher.data.network.LoginResponse>

    fun performGoogleLogin(request: com.lernr.teacher.data.network.LoginRequest.GoogleLoginRequest): Observable<com.lernr.teacher.data.network.LoginResponse>

    fun performLogoutApiCall(): Observable<com.lernr.teacher.data.network.LogoutResponse>

    fun getBlogApiCall(): Observable<com.lernr.teacher.data.network.BlogResponse>

    fun getOpenSourceApiCall(): Observable<com.lernr.teacher.data.network.OpenSourceResponse>

}