package com.lernr.teacher.ui.login

import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 10/01/18.
 */
@Module
class LoginActivityModule {

    @Provides
    internal fun provideLoginInteractor(interactor: com.lernr.teacher.ui.login.interactor.LoginInteractor): com.lernr.teacher.ui.login.interactor.LoginMVPInteractor = interactor

    @Provides
    internal fun provideLoginPresenter(presenter: com.lernr.teacher.ui.login.presenter.LoginPresenter<com.lernr.teacher.ui.login.view.LoginMVPView, com.lernr.teacher.ui.login.interactor.LoginMVPInteractor>)
            : com.lernr.teacher.ui.login.presenter.LoginMVPPresenter<com.lernr.teacher.ui.login.view.LoginMVPView, com.lernr.teacher.ui.login.interactor.LoginMVPInteractor> = presenter

}