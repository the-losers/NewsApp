package com.lernr.teacher.ui.feed.blog

import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
internal abstract class BlogFragmentProvider {

    @ContributesAndroidInjector(modules = [com.lernr.teacher.ui.feed.blog.BlogFragmentModule::class])
    internal abstract fun provideBlogFragmentFactory(): com.lernr.teacher.ui.feed.blog.view.BlogFragment
}