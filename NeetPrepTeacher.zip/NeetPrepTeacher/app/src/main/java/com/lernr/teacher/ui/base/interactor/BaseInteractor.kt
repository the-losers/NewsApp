package com.lernr.teacher.ui.base.interactor


open class BaseInteractor() : com.lernr.teacher.ui.base.interactor.MVPInteractor {

    protected lateinit var preferenceHelper: com.lernr.teacher.data.preferences.PreferenceHelper
    protected lateinit var apiHelper: com.lernr.teacher.data.network.ApiHelper

    constructor(preferenceHelper: com.lernr.teacher.data.preferences.PreferenceHelper, apiHelper: com.lernr.teacher.data.network.ApiHelper) : this() {
        this.preferenceHelper = preferenceHelper
        this.apiHelper = apiHelper
    }

    override fun isUserLoggedIn() = this.preferenceHelper.getCurrentUserLoggedInMode() != com.lernr.teacher.util.AppConstants.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT.type

    override fun performUserLogout() = preferenceHelper.let {
        it.setCurrentUserId(null)
        it.setAccessToken(null)
        it.setCurrentUserEmail(null)
        it.setCurrentUserLoggedInMode(com.lernr.teacher.util.AppConstants.LoggedInMode.LOGGED_IN_MODE_LOGGED_OUT)
    }

}